from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.base, name='base'),
	url(r'^recreational$', views.viewRecreational, name='viewRecreational'),
	url(r'^small$', views.viewSmall, name='viewSmall'),
	url(r'^free$', views.viewFree, name='viewFree'),
]
