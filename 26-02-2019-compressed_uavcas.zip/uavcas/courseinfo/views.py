# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from core.contexts import default
from store.models import Course

# Simple Page Views

def base(request):
    context = default(request)
    context["title"] = "Our Courses"
    context["loginUrl"] = "service=/courses/my/"
    return render(request, 'courseinfo/main.html', context)

def viewRecreational(request):
    id = 2
    course = Course.objects.get(moodle_id=id)

    context = default(request)
    context["title"] = course.course_name
    context["courseId"] = id
    context["price"] = course.cost
    context["loginUrl"] = "service=/courses/my/"
    return render(request, 'courseinfo/rec.html', context)
    
def viewSmall(request):
    context = default(request)
    context["title"] = "Very Small UAV Course"
    context["courseId"] = -1
    context["loginUrl"] = "service=/courses/my/"
    return render(request, 'courseinfo/small.html', context)
    
def viewFree(request):
    context = default(request)
    context["title"] = "Free Uav Course"
    context["courseId"] = -2
    context["loginUrl"] = "service=/courses/my/"
    return render(request, 'courseinfo/free.html', context)