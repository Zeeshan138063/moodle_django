# -*- coding: utf-8 -*-
from account.models import Purchase, PurchasedEmail
from store.models import Course

def getHistory(username):
	courses = getPurchasedCourses(username)
	history = {
		"courses": getEnrolledCourses(username),
		"purchases": getPurchases(username),
		"purchasedForOthers": getPurchasesForOthers(username)
	}
	return {"history": history}
	
def getPurchasesForOthers(username):
	forOthersTemp = {}
	forOthers = []
	purchases = PurchasedEmail.objects.filter(purchaser=username).order_by('is_active')
	for purchase in purchases:
		p = {
			"email": purchase.email,
			"is_active": purchase.is_active,
			"id": purchase.id
		}
		id = str(purchase.course_id)
		if id in forOthersTemp:
			forOthersTemp[id].append(p)
		else:
			forOthersTemp[id] = [p]
	for key, value in forOthersTemp.iteritems():
		id = int(key)
		course = Course.objects.get(moodle_id=id)
		for entry in value:
			entry["course"] = course.course_name
			forOthers.append(entry)
	return forOthers
	
def getPurchases(username):
	purchaseList = []
	purchases = Purchase.objects.filter(purchaser=username).order_by('created')
	for purchase in purchases:
		course = Course.objects.get(moodle_id=purchase.course_id)
		count = 0
		if purchase.purchase_self:
			count = 1
		count += purchase.other_count
		totalCost = count * purchase.purchase_price
			
		purchDict = {
			"course": course.course_name,
			"total_cost": totalCost,
			"purchase_self": purchase.purchase_self,
			"purchase_others": purchase.other_count,
			"created": purchase.created
		}
		purchaseList.append(purchDict)
	return purchaseList
	
def getPurchasedCourses(username):
	courses = []
	purchases = Purchase.objects.filter(purchaser=username)
	for purchase in purchases:
		course = Course.objects.get(moodle_id=purchase.course_id)
		courses.append(course.course_name)
	return courses
	
def getPurchasedEnrolledCourses(username):
	courses = []
	purchases = Purchase.objects.filter(purchaser=username, purchase_self=True)
	for purchase in purchases:
		course = Course.objects.get(moodle_id=purchase.course_id)
		courses.append(course.course_name)
	return courses
	
	
def getEnrolledCourses(username):
	courses = getPurchasedEnrolledCourses(username)
	courses2 = getCoursesBoughtForUser(username)
	for course in courses2:
		if course not in courses:
			courses.append(course)
	return courses
	
	
def getCoursesBoughtForUser(username):
	courses = []
	rawCourses = PurchasedEmail.objects.filter(is_active=True)
	for c in rawCourses:
		#Purchaser may not follow same capitalization convention as user
		if c.email.lower() == username.lower():
			course = Course.objects.get(moodle_id=c.course_id)
			courses.append(course.course_name)
	return courses
	