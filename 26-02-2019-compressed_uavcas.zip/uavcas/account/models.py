# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class Verification(models.Model):
	username = models.CharField(max_length=255)
	token = models.CharField(max_length=255)
	code = models.IntegerField()
	created = models.DateTimeField(auto_now_add=True)
	
	def __str__(self):
		return self.token
		
#Emails that had courses purchased for them by another
class PurchasedEmail(models.Model):
	purchaser = models.CharField(max_length=255)
	email = models.CharField(max_length=255)
	course_id = models.IntegerField()
	token = models.CharField(max_length=255)
	is_active = models.BooleanField(default=False)
	activated = models.DateTimeField(null=True)
	created = models.DateTimeField(auto_now_add=True)
	
	def __str__(self):
		return self.purchaser + ": " + self.email
		
class Purchase(models.Model):
	purchaser = models.CharField(max_length=255)
	course_id = models.IntegerField()
	purchase_price = models.DecimalField(max_digits=8, decimal_places=2, default=50.00)
	purchase_self = models.BooleanField(default=True)
	other_count = models.IntegerField()
	created = models.DateTimeField(auto_now_add=True)
	
	def __str__(self):
		return self.purchaser + ": " + self.course_id