# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib.auth.decorators import login_required
from django.http import Http404, HttpResponse, HttpResponseBadRequest, HttpResponseForbidden, HttpResponseRedirect, JsonResponse
from django.shortcuts import render, redirect
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from django.views.decorators.http import require_POST
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm

from account import registration as reg
from account import history
from core.contexts import default
from core.email import Email

import json
import logging
logger = logging.getLogger(__name__)


@login_required(redirect_field_name="service")
def changePassword(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password was successfully updated')
            return redirect('/account')
        else:
            messages.error(request, 'Please correct the error below.')
            context = default(request)
            context["title"] = "Change Password"
            context["form"] = form
            return render(request, 'account/changepassword.html', context)
    else:
        context = default(request)
        context["title"] = "Change Password"
        context["form"] = PasswordChangeForm(request.user)
        return render(request, 'account/changepassword.html', context)

@login_required(redirect_field_name="service")
def base(request):
    context = default(request)
    context["title"] = "Account"
    context["email"] = request.user.username
    context["firstName"] = request.user.first_name
    context["lastName"] = request.user.last_name
    context["loginUrl"] = "service=/account"
    context["description"] = ""
    return render(request, 'account/main.html', context)
    
@ensure_csrf_cookie
def register(request, token):
    #This is registering from an email message
    #No reason to verify email as their recieving it verifies it
    errors = request.GET.get("errors", None)
    if errors is None:
        errorMessages = []
    else:
        errorMessages = errors.split(";")
    if reg.emailTokenValid(token):
        #has correct token
        context = default(request)
        context["title"] = "Registration"
        context["requiredEmail"] = reg.getEmailFromToken(token)
        context["errorMessages"] = errorMessages
        context["loginUrl"] = "service=/account/register/" + token
        context["description"] = ""
        return render(request, 'account/register.html', context)
    else:
        raise Http404("Page Does Not Exist")
    
    
    
"""
    Page for after a user self-registers but needs to verify their email
"""
def verifyRegistration(request, token):
    if reg.isTokenValid(token):
        context = default(request)
        context["title"] = "Registration"
        context["token"] = token
        context["loginUrl"] = "service=/account/verify"
        context["description"] = ""
        return render(request, 'account/verify.html', context)
    else:
        raise Http404("Page Does Not Exist")
    
    
    
@ensure_csrf_cookie 
def selfRegister(request):
    errors = request.GET.get("errors", None)
    if errors is None:
        errorMessages = []
    else:
        errorMessages = errors.split(";")
    context = default(request)
    context["title"] = "Registration"
    context["errorMessages"] = errorMessages
    context["loginUrl"] = "service=/account/register"
    context["description"] = ""
    return render(request, 'account/self_register.html', context)
    
def viewSuccess(request):
    context = default(request)
    context["title"] = "Registration Successful"
    context["description"] = ""
    return render(request, 'account/success.html', context)
    
"""
    This is the case when a user is already registered but someone bought them a course
"""
@ensure_csrf_cookie
@login_required(redirect_field_name="service")
def viewExistingEnroll(request, token):
    if reg.emailTokenValid(token) and reg.emailMatchesToken(request.user.email, token):
        #Sign them up and tell them its great
        courseList = reg.getEmailCourses(request.user.username, token)
        reg.setupMoodle(request.user.username, request.user.first_name, request.user.last_name, courseList)
        reg.activateEmailCourse(request.user.username, token)
        
        context = default(request)
        context["title"] = "Enroll"
        context["loginUrl"] = "service=/"
        context["description"] = ""
        return render(request, 'account/existing_enroll.html', context)
    else:
        raise Http404("Page Does Not Exist")
    
    
    
@require_POST
@csrf_protect
def registerUserFromEmail(request, token):
    post = request.POST
    params, errors = reg.checkParams(post)
    if reg.emailTokenValid(token) and reg.emailMatchesToken(params["username"], token):
        if len(errors) > 0:
            for error in errors:
                messages.error(request, error)
            return HttpResponseRedirect("/account/register/" + token)
        else:
            courseList = reg.getEmailCourses(params["username"], token)
            reg.addTempUserToDjango(params["username"], params["firstName"], params["lastName"], params["email"], params["password"], False)
            #tempToken Not needed, this comes from email
            reg.makeUserActive(params["username"])
            reg.setupMoodle(params["username"], params["firstName"], params["lastName"], [3])
            reg.setupMoodle(params["username"], params["firstName"], params["lastName"], courseList)
            reg.activateEmailCourse(params["username"], token)
            return HttpResponseRedirect("/account/success")
    else:
        return HttpResponseBadRequest("Cannot register. The most likely issue is that the email provided does not match that on record")
    
@require_POST
@csrf_protect
def registerUserStep1(request):
    #Self registration step 1, try to register, and if the info is good, you're asked to verify your email
    post = request.POST
    params, errors = reg.checkParams(post)
    if len(errors) > 0:
        for error in errors:
            messages.error(request, error)
        return HttpResponseRedirect("/account/register")
    else:
        #ADD THEM TO DJANGO
        token = reg.addTempUserToDjango(params["username"], params["firstName"], params["lastName"], params["email"], params["password"])
        return HttpResponseRedirect("/account/verify/" + token)

@require_POST
@csrf_protect
def registerUserStep2(request):
    post = request.POST
    code = post.get("code", None)
    token = post.get("token", None)
    next = None
    if code is None or token is None:
        return HttpResponseBadRequest("missing parameters")
    else:
        try:
            code = int(code)
        except:
            return HttpResponseBadRequest("invalid code")
        success = reg.addUserFromCode(code, token)
        if success:
            messages.success(request, 'You have been successfully registered -- please login')
            if next is None:
                return HttpResponseRedirect("/courses/my")
            else:
                return HttpResponseRedirect(next)
        else:
            messages.error(request, 'Code is invalid')
            return HttpResponseRedirect("/account/verify/" + token)
    

@require_POST
@csrf_protect
@login_required(redirect_field_name="service")                  
def notifyBehalfEmails(request):
    post = request.POST
    data = json.loads(post.get("data"))
    purchaser = request.user
    targetEmails = data["targetEmails"]
    emailList = data["emailList"]
    if targetEmails is None or emailList is None:
        return HttpResponseBadRequest("Missing Parameters")
    else:
        success = reg.notifyBehalfEmails(purchaser, targetEmails, emailList)
        return JsonResponse({"success": success})
    
    
    
@login_required(redirect_field_name="service")
def getHistory(request):
    response = history.getHistory(request.user.username)
    return JsonResponse(response)
    
    
    
    
    