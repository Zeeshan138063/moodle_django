# -*- coding: utf-8 -*-
from django.utils import timezone
from django.contrib.auth import authenticate, login, get_user_model
from django.core.validators import validate_email

from account.models import Verification, PurchasedEmail
from core.email import Email
from core.models import UserManager, User
from datetime import timedelta, datetime
from store.models import Course

import requests
import random
import uuid
import logging
logger = logging.getLogger(__name__)


def checkParams(post):
    errors = []
    password = post.get("password", None)
    password2 = post.get("password2", None)
    email = post.get("email", None)
    username = email
    firstName = post.get("firstname", None)
    lastName = post.get("lastname", None)
    gcaptcharesponse = post.get("g-recaptcha-response", None)
        
    if username is None or password is None or password2 is None or email is None or firstName is None or lastName is None or gcaptcharesponse is None:
        errors.append("Error: There are missing parameters, please check your entries and try again")
    if validateRecaptcha(gcaptcharesponse) == False:
        errors.append("Error: The captcha input was not valid, make sure to check the captcha checkbox and follow any instructions given")
    else:
        valid = validateUserData(username, firstName, lastName, email, password, password2)
        if valid["valid"] == False:
            errors.extend(valid["reasons"])
    params = {
        "username": username,
        "password": password,
        "email": email,
        "firstName": firstName,
        "lastName": lastName
    }
    return params, errors

    
def userExists(username):
    for user in User.objects.all():
        #Don't add users with same case insensitive username/email
        if user.username.lower() == username.lower():
            return True
        elif user.email.lower() == username.lower():
            return True
    return False


def addTempUserToDjango(username, firstName, lastName, email, password, verify=True):
    #Add user and flag as inactive until verified
    user = get_user_model().objects.create_user(username, email, firstName, lastName, password)
    user.is_active = False
    user.save()
    
    #A uuid token, and a 4 digit code to match from email
    token = uuid.uuid4()
    code = random.randint(1000, 9999)
    v = Verification(username=username, code=code, token=str(token))
    v.save()
    if verify is True:
        textBody = """
            You have been sent a code to verify your email account by A3 UAV Pilot Training. The code is: {code} <br/><br/><br/>
            Contact <a href="mailto:support@a3uav.com">support@a3uav.com</a> if you have any issues
        """.format(code=str(code))
        #Send Verification email
        verEmail = Email("Verify Your Account for A3 UAV Pilot Training", textBody, [email])
        verEmail.send()
    return str(token)

def isTokenValid(token):
    if Verification.objects.filter(token=token).exists():
        v = Verification.objects.filter(token=token)[0]
        if timezone.now() > v.created + timedelta(hours=3):
            return False
        else:
            return True
    else:
        return False

def addUserFromCode(code, token):
    if isTokenValid(token):
        if Verification.objects.filter(token=token).exists():
            v = Verification.objects.filter(token=token)[0]
            #log(v.code)
            #log(code)
            if v.code == code:
                #FLIP DJANGO SWITCH TO ENABLED FOR THIS USER
                username = v.username
                makeUserActive(username)
                user = User.objects.get(username=username)
                setupMoodle(username, user.first_name, user.last_name, [3]) #will add free course
                return True
            else:
                return False
        else:
            return False
    else:
        return False
    
    
def notifyBehalfEmails(purchaser, emailTargets, emailList):
    for email in emailList:
        id = email[0]
        address = email[1]
        if address != "" and validate_email(address) is False:
            return False
        pe = PurchasedEmail.objects.get(purchaser=purchaser.username, id=id)
        if pe.email is None or pe.email != address:
            pe.email = address
            pe.save()
        if id in emailTargets:
            notifyBehalfEmail(id, purchaser)
    return True
            
def notifyBehalfEmail(id, purchaser):
    pe = PurchasedEmail.objects.get(id=id)
    if pe.email != "" and pe.is_active is False:
        course = Course.objects.get(moodle_id=pe.course_id)
        token = pe.token
        courseName = course.course_name
        targetEmail = pe.email
        
        purchaserFull = purchaser.first_name + " " + purchaser.last_name + " (" + purchaser.username + ")"
        
        if userExists(targetEmail):
            url = "https://uavpilottraining.a3uav.com/account/existing/" + token
            path = "{url} to enroll".format(url=url)
        else:
            url = "https://uavpilottraining.a3uav.com/account/register/" + token
            path = "{url} to register and enroll".format(url=url)
            
        textBody = """<h3>An A3 UAV Training Course ({courseName}) has been purchased for you by {purchaser}.</h3>
            Please visit {path}.<br/>Please check with the purchaser before continuing, to make sure this wasn't in error. Thanks! <br/><br/><br/>
            Contact <a href="mailto:support@a3uav.com">support@a3uav.com</a> if you have any issues
        """.format(courseName=courseName, purchaser=purchaserFull, path=path)
        
        verEmail = Email("A3 UAV Pilot Training - Course Enrollment", textBody, [targetEmail])
        verEmail.send()
    
    
def activateEmailCourse(username, token):
    link = PurchasedEmail.objects.filter(token=token)
    for row in link:
        #May have been saved with different capitalization than user uses
        if row.email.lower() == username.lower():
            row.is_active = True
            row.activated = datetime.now()
            row.save()
    
    
def getEmailCourses(email, token):
    link = PurchasedEmail.objects.filter(token=token)
    courses = []
    for row in link:
        if row.email.lower() == email.lower():
            courses.append(row.course_id)
        
    return courses
    
def getEmailFromToken(token):
    link = PurchasedEmail.objects.filter(token=token)
    if len(link) > 0:
        return link[0].email
    else:
        return None
    
def emailTokenValid(token):
    link = PurchasedEmail.objects.filter(token=token, is_active=False).exists()
    if link:
        return True
    else:
        return False
        
def emailMatchesToken(email, token):
    link = PurchasedEmail.objects.filter(token=token)
    for line in link:
        if line.email.lower() == email.lower():
            return True
    else:
        return False
    
def makeUserActive(username):
    user = User.objects.get(username=username)
    user.is_active = True
    user.save()
    
def validateRecaptcha(recaptcha):
    url = "https://www.google.com/recaptcha/api/siteverify"
    secret = "6Lf7Qj8UAAAAAGDdKyGlQljqZv2sVqmkpoYzghLW"
    data = {
        "secret": secret,
        "response": recaptcha
    }
    r = requests.post(url, data=data)
    rj = r.json()
    return rj["success"]

def validateUserData(username, firstName, lastName, email, password, password2):
    validation = True
    reasons = []
    if password != password2:
        validation = False
        reasons.append("Error: The provided passwords do not match")
    if len(password) < 8:
        validation = False
        reasons.append("Error: The password is too short")
    if userExists(username):
        validation = False
        reasons.append("Error: The provided email is already registered in our system, are you already registered?")
    if validate_email(username) is False or validate_email(email) is False:
        validation = False
        reasons.append("Error: The email provided is not valid")
    return {"valid": validation, "reasons": reasons}


def addUserToMoodle(username, firstName, lastName):
    #Take Username and get details from CAS
    username = username.lower() #Flatten for moodle
    email = username
    moodleUrlTemplate = "https://uavpilottraining.a3uav.com/courses/webservice/rest/server.php?wstoken=bc5cd61962a9bd8fb02422f3138624c6&wsfunction=core_user_create_users&moodlewsrestformat=json&users[0][username]={username}&users[0][firstname]={firstName}&users[0][lastname]={lastName}&users[0][email]={email}&users[0][auth]=cas"
    moodleUrl = moodleUrlTemplate.format(username=username, firstName=firstName, lastName=lastName, email=email)
    moodleR = requests.get(moodleUrl)
    jResult = moodleR.json()
    if isinstance(jResult, list):
        #If its a list, then we've won, else it's a dict of exception info, stupid moodle
        id = jResult[0]["id"]
        return (True, id)
    else:
        e = jResult["exception"]
        errorCode = jResult["errorcode"]
        if "message" in jResult:
            message = jResult["message"]
        else:
            message = "No message supplied"
        logger.debug("Error Adding User")
        logger.debug(e)
        logger.debug(errorCode)
        logger.debug(message)
        return (False, -1)
    
def disableMoodleUser(moodleUserId):
    #This is done before payment is received but after adding them to avoid logins when there are payment errors
    moodleUrlTemplate = "https://uavpilottraining.a3uav.com/courses/webservice/rest/server.php?wstoken=bc5cd61962a9bd8fb02422f3138624c6&wsfunction=core_user_update_users&moodlewsrestformat=json&users[0][id]={userId}&users[0][suspended]=1"
    moodleUrl = moodleUrlTemplate.format(userId=moodleUserId)
    moodleR = requests.get(moodleUrl)
    jResult = moodleR.json()
    if jResult is None:
        #Remarkably this means it worked. I hate moodle.
        return True
    else:
        e = jResult["exception"]
        errorCode = jResult["errorcode"]
        if "message" in jResult:
            message = jResult["message"]
        else:
            message = "No message supplied"
        logger.debug("Error Adding User")
        logger.debug(e)
        logger.debug(errorCode)
        logger.debug(message)
        return False
        
def enableMoodleUser(moodleUserId):
    #This is done before payment is received but after adding them to avoid logins when there are payment errors
    moodleUrlTemplate = "https://uavpilottraining.a3uav.com/courses/webservice/rest/server.php?wstoken=bc5cd61962a9bd8fb02422f3138624c6&wsfunction=core_user_update_users&moodlewsrestformat=json&users[0][id]={userId}&users[0][suspended]=0"
    moodleUrl = moodleUrlTemplate.format(userId=moodleUserId)
    moodleR = requests.get(moodleUrl)
    jResult = moodleR.json()
    if jResult is None:
        #Remarkably this means it worked. I hate moodle.
        return True
    else:
        e = jResult["exception"]
        errorCode = jResult["errorcode"]
        if "message" in jResult:
            message = jResult["message"]
        else:
            message = "No message supplied"
        logger.debug("Error Adding User")
        logger.debug(e)
        logger.debug(errorCode)
        logger.debug(message)
        return False
    
def getUserMoodleId(username):
    username = username.lower() #flatten for moodle
    urlRaw = "https://uavpilottraining.a3uav.com/courses/webservice/rest/server.php?wstoken=bc5cd61962a9bd8fb02422f3138624c6&wsfunction=core_user_get_users&moodlewsrestformat=json&criteria[0][key]=username&criteria[0][value]={username}"
    url = urlRaw.format(username=username)
    response = requests.get(url)
    x = response.text
    jResult = response.json()
    if "users" in jResult:
        #Yet another way to return things woo
        users = jResult["users"]
        if len(users) > 0:
            return users[0]["id"]
        else:
            return None
    else:
        e = jResult["exception"]
        errorCode = jResult["errorcode"]
        if "message" in jResult:
            message = jResult["message"]
        else:
            message = "No message supplied"
        logger.debug("Error Adding User")
        logger.debug(e)
        logger.debug(errorCode)
        logger.debug(message)
        return -1 #kind of silly marking it this way, but don't want scary unhandled exception here
    
    
def enrolUserInCourse(moodleUserId, moodleCourseId):
    urlRaw = "https://uavpilottraining.a3uav.com/courses/webservice/rest/server.php?wstoken=bc5cd61962a9bd8fb02422f3138624c6&wsfunction=enrol_manual_enrol_users&moodlewsrestformat=json&enrolments[0][roleid]=5&enrolments[0][userid]={userId}&enrolments[0][courseid]={courseId}"
    url = urlRaw.format(userId=moodleUserId, courseId=moodleCourseId)
    response = requests.get(url)
    jResult = response.json()
    logger.debug(jResult)
    if jResult is None:
        #Remarkably this means it worked. I hate moodle.
        return True
    else:
        e = jResult["exception"]
        errorCode = jResult["errorcode"]
        if "message" in jResult:
            message = jResult["message"]
        else:
            message = "No message supplied"
        logger.debug("Error Enrolling User")
        logger.debug(e)
        logger.debug(errorCode)
        logger.debug(message)
        return False
    
def unenrollUserInCourse(moodleUserId, moodleCourseId):
    urlRaw = "https://uavpilottraining.a3uav.com/courses/webservice/rest/server.php?wstoken=bc5cd61962a9bd8fb02422f3138624c6&wsfunction=enrol_manual_unenrol_users&moodlewsrestformat=json&enrolments[0][roleid]=5&enrolments[0][userid]={userId}&enrolments[0][courseid]={courseId}"
    url = urlRaw.format(userId=moodleUserId, courseId=moodleCourseId)
    response = requests.get(url)
    jResult = response.json()
    logger.debug(jResult)
    if jResult is None:
        #Remarkably this means it worked. I hate moodle.
        return True
    else:
        e = jResult["exception"]
        errorCode = jResult["errorcode"]
        if "message" in jResult:
            message = jResult["message"]
        else:
            message = "No message supplied"
        logger.debug("Error Unenrolling User")
        logger.debug(e)
        logger.debug(errorCode)
        logger.debug(message)
        return False
    
    
def setupMoodle(username, firstName, lastName, courseIds):
    #Create new or get existing id
    testId = getUserMoodleId(username)
    id = None
    if testId is None:
        add = addUserToMoodle(username, firstName, lastName)
        if add[0]:
            id = add[1]
        else:
            return False
    elif testId == -1:
        return False
    else:
        #Already Exists
        id = testId
        
    #Enrol user
    for courseId in courseIds:
        enrol = enrolUserInCourse(id, courseId)
        if enrol is False:
            return False
            
    return True
        
def disableMoodle(username, courseIds):
    #Create new or get existing id
    testId = getUserMoodleId(username)
    id = None
    if testId is None:
        return False
    elif testId == -1:
        return False
    else:
        #Already Exists
        id = testId
        
    #Unenroll user
    for courseId in courseIds:
        enrol = unenrollUserInCourse(id, courseId)
            
    return True
    
    
    
    



