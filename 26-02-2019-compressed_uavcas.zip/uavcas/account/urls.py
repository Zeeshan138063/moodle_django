from django.conf.urls import url
from django.contrib.auth import views as auth_views

from . import views

urlpatterns = [
    url(r'^$', views.base, name='base'),
    url(r'^register$', views.selfRegister, name='selfRegister'),
    url(r'^register/([-\w]+)$', views.register, name='register'),
    url(r'^verify/([-\w]+)$', views.verifyRegistration, name='verifyRegistration'),
    url(r'^add$', views.registerUserStep1, name='registerUserStep1'),
    url(r'^add/([-\w]+)$', views.registerUserFromEmail, name='registerUserFromEmail'),
    url(r'^verify$', views.registerUserStep2, name='registerUserStep2'),
    url(r'^success$', views.viewSuccess, name='viewSuccess'),
    url(r'^existing/([-\w]+)$', views.viewExistingEnroll, name='viewExistingEnroll'),
    url(r'^history$', views.getHistory, name='getHistory'),
    url(r'^notify$', views.notifyBehalfEmails, name='notifyBehalfEmails'),
    
    #url(r'^forgot$', views.forgotPassword, name='forgotPassword'),

    url(r'^changepassword$', views.changePassword, name='changePassword'),
    
    url(r'^password_reset/$', auth_views.password_reset, name='password_reset'),
    url(r'^password_reset/done/$', auth_views.password_reset_done, name='password_reset_done'),
    url(r'^reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$', auth_views.password_reset_confirm, name='password_reset_confirm'),
    url(r'^reset/done/$', auth_views.password_reset_complete, name='password_reset_complete'),
]