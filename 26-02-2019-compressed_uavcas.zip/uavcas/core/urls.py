from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.viewWelcome, name='viewWelcome'),
	url(r'^about$', views.viewAbout, name='viewAbout'),
	url(r'^terms$', views.viewTerms, name='viewTerms'),
	url(r'^privacy$', views.viewPrivacy, name='viewPrivacy'),
]
