



recCourse = {"label": "Recreational Training", "href": "/courseinfo/recreational"}
profCourse = {"label": "Professional Training", "href": "/courseinfo/professional"}
aboutUs = {"label": "About Us", "href": "/welcome/about"}
goToCourses = {"label": "Go To Courses", "href": "/courses/my"}
register = {"label": "Register", "href": "/account/register"}
ourCourses = {"label": "Our Courses", "href": "/courseinfo"}


def custom(label, href):
	return {
		"label": label,
		"href": href
	}