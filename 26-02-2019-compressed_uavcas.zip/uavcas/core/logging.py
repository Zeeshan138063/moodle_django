import datetime
from django.conf import settings

def log(content):
	logPath = "/var/log/django.log"
	file = open(logPath, 'a')
	file.write(datetime.datetime.now().isoformat(' ') + " - " + unicode(content) + "\n")
	file.close()
