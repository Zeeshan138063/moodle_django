# -*- coding: utf-8 -*-
from store import cart


def default(request):
	context = {
		"cartTotal": cart.getTotalCourses(request.session),
		"cost": cart.getTotalCost(request.session)
	
	}
	return context