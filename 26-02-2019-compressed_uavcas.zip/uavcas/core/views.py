# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from core.contexts import default

def viewWelcome(request):
    context = default(request)
    context["title"] = "A3 UAV Pilot Training"
    context["loginUrl"] = "service=/courses/my/"
    return render(request, 'core/welcome.html', context)

def viewAbout(request):
    context = default(request)
    context["title"] = "About A3 UAV"
    context["loginUrl"] = "service=/courses/my/"
    context["description"] = "How can we help you fly your UAV (Unmanned Aerial Vehicle) or drone?  A3UAV Pilot Training was created in Grande Prairie, which is in Northern Alberta, Canada.  We work in the aviation industry, we understand the importance of training and we also enjoy flying UAV’s ourselves.  Our pilots have UAV pilot training certification and decades of helicopter and airplane experience, this expert level knowledge is available to you in our courses and also as support.  Feel free to email us with your questions <a href='mailto:support@a3uav.com'>support@a3uav.com</a>."
    return render(request, 'core/about.html', context)
    
def viewTerms(request):
    context = default(request)
    context["title"] = "A3 UAV Pilot Training Terms of Service"
    context["loginUrl"] = "service=/courses/my/"
    context["description"] = ""
    return render(request, 'core/terms.html', context)
    
def viewPrivacy(request):
    context = default(request)
    context["title"] = "A3 UAV Pilot Training Privacy Policy"
    context["loginUrl"] = "service=/courses/my/"
    context["description"] = ""
    return render(request, 'core/privacy.html', context)