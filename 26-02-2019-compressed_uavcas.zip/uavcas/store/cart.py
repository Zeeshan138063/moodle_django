# -*- coding: utf-8 -*-

def getTotalCost(session):
	cost = 0
	if "courses" in session:
		for course in session["courses"]:
			cost += float((course["quantity"] * course["cost"]) / 100)
	return cost
		
def getTotalCourses(session):
	if "courses" in session:
		return len(session["courses"])
	else:
		return 0
		
def getCourses(session):
	if "courses" in session:
		return session["courses"]
	else:
		return []

def empty(session):
	session["courses"] = []
	
def hasSelfPurchase(session):
	if "courses" in session:
		for course in session["courses"]:
			if course["selfPurchase"] is True:
				return True
		return False
	else:
		return False
		
def addCourse(session, id, quantity, selfPurchase, cost):
	cartItem = {
		"id": id,
		"quantity": quantity,
		"cost": cost,
		"selfPurchase": selfPurchase
	}
	if "courses" not in session:
		session["courses"] = []
	session["courses"].append(cartItem)
	session.modified = True
	