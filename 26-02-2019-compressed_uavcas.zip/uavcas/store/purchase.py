import uuid
import squareconnect
from squareconnect.rest import ApiException
from squareconnect.apis.transactions_api import TransactionsApi
from django.conf import settings
from account.models import Purchase, PurchasedEmail
from store import cart

def charge(nonce, cost, billing, email):
    squareconnect.configuration.access_token = settings.SQUARETOKEN
    api_instance = TransactionsApi()
    location_id = settings.SQUARELOCATIONID
    # Charge
    idempotency_key = str(uuid.uuid1())
    
    #Bizarrely, this is in cents
    amount = {'amount': int(cost * 100), 'currency': 'CAD'}
    body = {'idempotency_key': idempotency_key, 'card_nonce': nonce, 'amount_money': amount, 'billing_address': billing, 'buyer_email_address': email}
    api_response = api_instance.charge(location_id, body)
    status = api_response.transaction.tenders[0].card_details.status
    if status == "CAPTURED":
        return "success"
    else:
        return api_response["errors"]
        
def recordPurchase(username, session):
    courses = cart.getCourses(session)
    for course in courses:
        courseId = course["id"]
        quantity = course["quantity"]
        cost = course["cost"]
        #Saved in cents, change to dollars for DB
        cost = cost / 100
        selfPurchase = course["selfPurchase"]
        if selfPurchase is True:
            purchaseOthers = quantity - 1
        else:
            purchaseOthers = quantity
        p = Purchase(purchaser=username, course_id=courseId, purchase_price=cost, purchase_self=selfPurchase, other_count=purchaseOthers)
        p.save()
        for x in range(purchaseOthers):
            token = uuid.uuid4()
            pe = PurchasedEmail(purchaser=username, course_id=courseId, token=token, is_active=False)
            pe.save()
        
