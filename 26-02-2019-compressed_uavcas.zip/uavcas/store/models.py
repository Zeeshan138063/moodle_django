# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models


class Course(models.Model):
	moodle_id = models.IntegerField(default=-1)
	course_name = models.CharField(max_length=255, default="Add Short Meaningful name")
	course_desc = models.TextField(max_length=2500, default="Add description for store")
	picture_path = models.CharField(max_length=255, default="/img/default.jpg")
	cost = models.DecimalField(max_digits=8, decimal_places=2, default=50.00)
	available = models.BooleanField(default=False)
	
	def __str__(self):
		return self.course_name