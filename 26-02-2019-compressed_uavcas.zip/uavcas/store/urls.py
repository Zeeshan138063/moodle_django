from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^(\d+)$', views.shop, name='shop'),
	url(r'^courses$', views.courses, name='courses'),
	url(r'^purchase$', views.purchase, name='purchase'),
	url(r'^purchase/handle$', views.purchaseHandle, name='purchaseHandle'),
	url(r'^purchase/success$', views.purchaseSuccess, name='purchaseSuccess'),
	url(r'^purchase/error$', views.purchaseError, name='purchaseError'),
	url(r'^addtocart$', views.addToCart, name='addToCart'),
	url(r'^carttotal$', views.getCartTotal, name='getCartTotal'),
    url(r'^emptycart$', views.emptyCart, name='emptyCart')
]
