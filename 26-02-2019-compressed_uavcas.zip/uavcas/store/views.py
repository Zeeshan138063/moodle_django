# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from django.http import HttpResponseBadRequest, HttpResponseNotFound, HttpResponse, Http404, JsonResponse, HttpResponseRedirect
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie, csrf_exempt
from django.views.decorators.cache import never_cache

from store.models import Course
from store import cart
from account.registration import setupMoodle, disableMoodle
from store.purchase import charge, recordPurchase
from core.contexts import default


@ensure_csrf_cookie
@login_required(redirect_field_name="service")
def purchaseSuccess(request):
    context = default(request)
    context["title"] = "Successful Purchase"
    context["loginUrl"] = "service=/store/success"
    context["description"] = ""
    return render(request, 'store/success.html', context)
    
@ensure_csrf_cookie
@login_required(redirect_field_name="service")
def purchaseError(request):
    context = default(request)
    context["title"] = "Transaction Failed"
    context["loginUrl"] = "service=/"
    context["description"] = ""
    return render(request, 'store/error.html', context)


@never_cache
@ensure_csrf_cookie
def shop(request, courseId):
    #return HttpResponse("We are not yet accepting payments, please check back")

    course = Course.objects.get(moodle_id=courseId)
    context = default(request)
    context["title"] = "Shop"
    context["courseId"] = courseId
    context["courseName"] = course.course_name
    context["courseDescription"] = course.course_desc
    context["courseCost"] = course.cost
    context["loginUrl"] = "service=/store/" + str(courseId)
    context["description"] = ""
    return render(request, 'store/shop.html', context)
    
@never_cache
@ensure_csrf_cookie
@login_required(redirect_field_name="service")
def purchase(request):
    total = cart.getTotalCourses(request.session)
    if total == 0:
        #No business on purchase with nothing purchased
        return HttpResponseRedirect("/")
    else:
        cartCourses = cart.getCourses(request.session)
        #Right now only one
        cartCourse = cartCourses[0]
        courseCost = cartCourse["cost"] / 100
        selfPurchase = cartCourse["selfPurchase"]
        quantity = cartCourse["quantity"]
        
        if selfPurchase:
            totalOthers = quantity - 1
        else:
            totalOthers = quantity
        
        totalCost = courseCost * quantity
        courseId = cartCourse["id"]
        course = Course.objects.get(moodle_id=courseId)
        courseName = course.course_name
        
        context = default(request)
        context["title"] = "Checkout"
        context["courseName"] = courseName
        context["courseCost"] = courseCost
        context["selfPurchase"] = selfPurchase
        context["totalOthers"] = totalOthers
        context["totalCourses"] = quantity
        context["totalCost"] = totalCost
        context["loginUrl"] = "service=/store/purchase"
        context["description"] = ""
        return render(request, 'store/purchase.html', context)





@never_cache
@require_POST
def addToCart(request):
    post = request.POST
    courseId = post.get("id")
    quantity = int(post.get("quantity"))
    selfPurchaseRaw = post.get("self_purchase")
    if selfPurchaseRaw == "true":
        selfPurchase = True
    else:
        selfPurchase = False
    course = Course.objects.get(moodle_id=courseId)
    
    if course is None:
        return HttpResponseBadRequest("missing parameters")
    else:
        cart.addCourse(request.session, courseId, quantity, selfPurchase, int(course.cost * 100))
        return JsonResponse({"total": cart.getTotalCourses(request.session), "cost": cart.getTotalCost(request.session)})
            
@never_cache     
@csrf_exempt
@require_POST   
def getCartTotal(request):
    return JsonResponse({"total": cart.getTotalCourses(request.session), "cost": cart.getTotalCost(request.session)})
        
@never_cache  
def courses(request):
    rawCourses = Course.objects.all()
    courses = []
    for course in rawCourses:
        if course.available:
            c = {
                "id": course.moodle_id,
                "course_name": course.course_name,
                "course_desc": course.course_desc,
                "picture_path": course.picture_path,
                "cost": course.cost
            }
            courses.append(c)
    return JsonResponse({"courses": courses})
    
@never_cache
def emptyCart(request):
    #Empty cart in case they've been clicking around already
    cart.empty(request.session)
    return JsonResponse({"emptied": True})
    
@never_cache
@login_required(redirect_field_name="service")
def purchaseHandle(request):
    nonce = request.POST.get("nonce", None)
    cost = float(request.POST.get("expected_cost", -1))
    billing = {
        "address_line_1": request.POST.get("address_line_1", ""),
        "address_line_2": request.POST.get("address_line_2", ""),
        "locality": request.POST.get("locality", ""),
        "administrative_district_level_1": request.POST.get("administrative_district_level_1", ""),
        "country": request.POST.get("country", ""),
        "postal_code": request.POST.get("postal_code", "")
    }
    if cost != -1.0:
        serverCost = cart.getTotalCost(request.session)
        if cost != serverCost:
            return HttpResponseBadRequest("Cart value does not match")
    else:
        return HttpResponseBadRequest("No expected cost")
    
    if nonce:
        #Here we enroll them so we don't charge if it fails
        setupResult = True
        if cart.hasSelfPurchase(request.session):
            courses = cart.getCourses(request.session)
            courseList = []
            for course in courses:
                courseList.append(course["id"])
            setupResult = setupMoodle(request.user.username, request.user.first_name, request.user.last_name, courseList)
        if setupResult is True:
            try:
                result = charge(nonce, cost, billing, request.user.email)
                if result == "success":
                    recordPurchase(request.user.username, request.session)
                    return HttpResponseRedirect("/store/purchase/success")
                else:
                    disableMoodle(request.user.username, courseList)
                    errorMessage = " : ".join(list(map(str, result)))
                    return HttpResponseBadRequest(errorMessage)
            except Exception as e:
                disableMoodle(request.user.username, courseList)
                raise
        else:
            return HttpResponseBadRequest("A problem was found setting up your course access, you have not been charged")
    else:
        return HttpResponseBadRequest("No nonce")
    

