import os
from decouple import config

os.environ["MJ_USER"] = config("MJ_USER")
os.environ["MJ_P"] = config("MJ_P")
SQUARETOKEN = config("SQUARETOKEN")
SQUARELOCATIONID = config("SQUARELOCATIONID")

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = config("KEY")

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

ALLOWED_HOSTS = ["*"]


# Application definition

INSTALLED_APPS = [
	'django.contrib.admin',
	'django.contrib.auth',
	'django.contrib.contenttypes',
	'django.contrib.sessions',
	'django.contrib.messages',
	'django.contrib.staticfiles',
	'core',
	'store',
	'account',
	'mama_cas'
]

MIDDLEWARE = [
	'django.middleware.security.SecurityMiddleware',
	'django.contrib.sessions.middleware.SessionMiddleware',
	'django.middleware.common.CommonMiddleware',
	'django.middleware.csrf.CsrfViewMiddleware',
	'django.contrib.auth.middleware.AuthenticationMiddleware',
	'django.contrib.messages.middleware.MessageMiddleware',
	'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'uavcas.urls'

TEMPLATES = [
	{
		'BACKEND': 'django.template.backends.django.DjangoTemplates',
		'DIRS': [os.path.join(BASE_DIR, 'templates/'),],
		'APP_DIRS': True,
		'OPTIONS': {
			'context_processors': [
				'django.template.context_processors.debug',
				'django.template.context_processors.request',
				'django.contrib.auth.context_processors.auth',
				'django.contrib.messages.context_processors.messages',
			],
		},
	},
]

WSGI_APPLICATION = 'uavcas.wsgi.application'


# Database
# https://docs.djangoproject.com/en/1.11/ref/settings/#databases

DATABASES = {
	'default': {
		'ENGINE': 'django.db.backends.postgresql_psycopg2',
		'NAME': 'cas',
		'USER': 'cas_user',
		'PASSWORD': 'D1H2sBuIJxvNVcRAG99g',
		'HOST': 'localhost',
		'PORT': '',
	}
}


# Password validation
# https://docs.djangoproject.com/en/1.11/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
	{
		'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
	},
	{
		'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
	},
	{
		'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
	},
	{
		'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
	},
]


# Internationalization
# https://docs.djangoproject.com/en/1.11/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True

#Logging
LOGGING = {
	'version': 1,
	'disable_existing_loggers': True,
	'formatters': {
		'standard': {
			'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
		},
	},
	'handlers': {
		'default': {
			'level':'DEBUG',
			'class':'logging.handlers.RotatingFileHandler',
			'filename': '/vol/logs/django/pilottraining.log',
			'maxBytes': 1024*1024*5,
			'backupCount': 10,
			'formatter':'standard',
		},  
		'request_handler': {
			'level':'DEBUG',
			'class':'logging.handlers.RotatingFileHandler',
			'filename': '/vol/logs/django/request.log',
			'maxBytes': 1024*1024*5,
			'backupCount': 5,
			'formatter':'standard',
		},
	},
	'loggers': {
		'': {
			'handlers': ['default'],
			'level': 'DEBUG',
			'propagate': True
		},
		'django.request': {
			'handlers': ['request_handler'],
			'level': 'INFO',
			'propagate': False
		},
	}
}




# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.11/howto/static-files/

STATIC_URL = '/static/'
STATIC_ROOT = 'static'

LOGIN_REDIRECT_URL = '/cas/login'
LOGIN_URL = '/cas/login'

AUTH_USER_MODEL = 'core.User'

MAMA_CAS_LOGIN_TEMPLATE = "login.html"
	
#EMAIL CONFIG
EMAIL_BACKEND = 'django_mailjet.backends.MailjetBackend'
#EMAIL_HOST = 'in-v3.mailjet.com'
#EMAIL_PORT = 587
#EMAIL_HOST_USER = os.environ["MJ_USER"]
#EMAIL_HOST_PASSWORD = os.environ["MJ_P"]
MAILJET_API_KEY = os.environ["MJ_USER"]
MAILJET_API_SECRET = os.environ["MJ_P"]
#EMAIL_USE_TLS = True
DEFAULT_FROM_EMAIL = "no.reply@uavpilottraining.a3uav.com"


